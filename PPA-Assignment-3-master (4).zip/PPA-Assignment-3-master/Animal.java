import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 * 
 * @author David J. Barnes and Michael Kölling
 * @modified by Taherah Choudhury and Arham Azhary
 * @version 24/02/2021 (3) 
 */
public abstract class Animal extends Organism
{
    private int age;
    private Gender gender;
    private int foodLevel;
    private boolean hasDisease;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomAge, Weather weather, Field field, Location location)
    {
        super(field, weather, location);
        hasDisease = false;
        giveGender();
        if(randomAge) {
            age = rand.nextInt(getMaxAge());
            foodLevel = rand.nextInt(getFoodValue());
        }
        else {
            age = 0;
            foodLevel = getFoodValue();
        }
    }

    /**
     * Gives a gender to this animal.
     * @return "male" or "female"
     */
    private void giveGender()
    {
        Random random = new Random();
        int num = random.nextInt(2)+1;
        if (num == 1){
            gender = Gender.FEMALE;
        }
        else{
            gender = Gender.MALE;
        }
    }

    /**
     * Returns the opposite gender of this animal.
     * @return MALE or FEMALE
     */
    private Gender getOppositeGender()
    {
        if (gender == Gender.FEMALE){
            return Gender.MALE;
        }
        return Gender.FEMALE;
    }

    /**
     * Returns the gender of this animal.
     */
    private Gender getGender()
    {
        return gender;
    }
    
    @Override
    protected void act(List<Organism> newOrganisms)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newOrganisms);            
            // Move towards a source of food if found.            
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(!getWeather().isFoggy()) {
                return;
            }
            
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if (!meet()){
            return births;
        }

        if(canBreed() && rand.nextDouble() <= getBreadingProb()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * A animal can breed if it has reached the breeding age.
     * @return true if the animal can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= getBreadingAge();
    }

    /**
     * Returns true when animal meets a neighbouring animal 
     * that is of the same species and is of opposite gender.
     */
    protected boolean meet()
    {
        Field field = getField();
        List<Location> locations = field.getOccupiedAdjacentLocations(getLocation());
        for (Location location: locations){
            Object object = field.getObjectAt(location);
            //checks if the animal is of the same species
            if (isInstanceOf(object)){
                Animal animal = (Animal) object;
                if(isDiseased() && !animal.isDiseased()){
                    animal.infect();
                }
                
                if (animal.getGender() == getOppositeGender()){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    protected void giveBirth(List<Organism> newAnimals)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        Weather weather = getWeather();
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            addNewAnimals(field, free, weather, newAnimals);
        }
    }

    /**
     * Look for food adjacent to the current location.
     * Only the first live food is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object object = field.getObjectAt(where);
            if(isFood(object)) { 
                Organism organism = (Organism) object;
                if(organism.isAlive()) { 
                    organism.setDead();
                    setFoodLevel();
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Increase the age.
     * This could result in the animals's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
        else if(hasDisease){
            age--;
        }
    } 

    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Sets the food level of this animal
     */
    protected void setFoodLevel()
    {
        foodLevel = getFoodValue();
    }
    
    /**
     * Returns true is this animal has a disease
     */
    public boolean isDiseased()
    {
        return hasDisease;
    }
    
    /**
     * Infects the animal with a disease
     */
    public void infect()
    {
        hasDisease = true;
    }

    // Abstract Methods:

    public abstract boolean isInstanceOf(Object object);

    public abstract int getMaxAge();

    public abstract int getFoodValue();

    public abstract int getBreadingAge();

    public abstract double getBreadingProb();

    public abstract int getMaxLitterSize();

    public abstract boolean isFood(Object object);

    public abstract void addNewAnimals(Field field, List<Location> free, Weather weather, List<Organism> newAnimals);
}

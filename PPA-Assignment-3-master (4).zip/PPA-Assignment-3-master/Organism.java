import java.util.List;
/**
 * Abstract class Organism - An organism in the savanna habitat. 
 *
 * @author Taherah Choudhury and Arham Azhary
 * @version 24/02/2021 (1)
 */
public abstract class Organism
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The weather condition at the current field.
    private Weather weather;
    
    /**
     * Create a new organism at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Organism(Field field, Weather weather, Location location)
    {
        alive = true;
        this.field = field;
        this.weather = weather;
        setLocation(location);
    }
    
    /**
     * Make this actor act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganism A list to receive newly born organisms.
     */
    protected abstract void act(List<Organism> newOrganisms);
    
    /**
     * Checks whether or not this organism is alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
     /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Return the weather condition of this habitat.
     * @return The weather .
     */
    protected Weather getWeather()
    {
        return weather;
    }
    
    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
}

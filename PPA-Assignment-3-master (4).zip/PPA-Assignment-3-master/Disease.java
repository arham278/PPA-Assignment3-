import java.util.List;
import java.util.Random;

/**
 * Class Disease - A disease that exists in the Savanna habitat 
 * which can infect the animals.
 *
 * @author Taherah Choudhury and Arham Azhary
 * @version 28/02/2021 (1)
 */
public class Disease extends Organism
{
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Intialises the location on the field of this disease.
     */
    public Disease(Field field, Weather weather, Location location)
    {
        super(field, weather, location); 
    }

    /**
     * Infects an animal near by if the animal has not yes gotton the disease.
     */
    @Override
    protected void act(List<Organism> newDiseases)
    {
        Animal animal = getAdjacentAnimal(getLocation()); 
        if(animal != null && !animal.isDiseased()) {
            int randomNumber = rand.nextInt(1000) + 1;
            if(randomNumber == 5) {
                animal.infect();
            }
        }
    }

    /**
     * Returns an animal adjacent to the given location.
     */
    private Animal getAdjacentAnimal(Location loc)
    {
        Field field = getField();
        Location location = field.occupiedAdjacentLocation(loc);
        if(location != null) {
            Object object = field.getObjectAt(location);
            //checks if the animal is of the same species
            if (object instanceof Animal){
                Animal animal = (Animal) object;
                return animal;
            }
        }
        return null;
    }
}

import java.util.Random;

/**
 * Class Weather - The type of weather changes that happen in the savanna habitat.
 *
 * @author Taherah Choudhury and Arham Azhary
 * @version 29/02/2021 (1) 
 */
public class Weather
{
    private static final Random rand = Randomizer.getRandom();
    
    private boolean clear;
    private boolean foggy;
    private boolean raining;

    /**
     * Initialises the weather to clear.
     */
    public Weather()
    {
        setClear();
    }

    /**
     * Return true if the weather is clear.
     * @return clear
     */
    public boolean isClear()
    {
        return clear;
    }

    /**
     * Return true if the weather is foggy.
     * @return foggy
     */
    public boolean isFoggy()
    {
        return foggy;
    }

    /**
     * Return true if the weather is raining.
     * @return raining
     */
    public boolean isRaining()
    {
        return raining;
    }

    /**
     * Sets the weather state to foggy.
     */
    public void setFoggy()
    {
        clear = false;
        foggy = true;
        raining = false;
    }

    /**
     * Sets the weather state to raining.
     */
    public void setRaining()
    {
        clear = false;
        foggy = false;
        raining = true;
    }

    /**
     * Sets the weather state to clear.
     */
    public void setClear()
    {
        clear = true;
        foggy = false;
        raining = false;
    }

    /**
     * Change randomly the weather condition. 
     */
    public void change()
    {
        int randomNumber = rand.nextInt(3) + 1;
        switch(randomNumber) {
            case 1:
            setClear();
            break;
            case 2:
            setFoggy();
            break;
            case 3:
            setRaining();
            break;
        }
    }
}

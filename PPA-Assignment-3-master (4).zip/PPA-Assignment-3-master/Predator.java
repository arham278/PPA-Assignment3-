import java.util.List;

/**
 * Abstract class Predator - Subclass of Animal
 *
 * @author Taherah Choudhury and Arham Azhary
 * @version 24/02/2021
 */
public abstract class Predator extends Animal
{
    
    /**
     * Create a new Predator at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(boolean randomAge, Weather weather, Field field, Location location)
    {
        super(randomAge, weather, field, location);
    }
}

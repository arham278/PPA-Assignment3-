import java.util.List;

/**
 * A simple model of a zebra.
 * Zebras age, move, breed, and die.
 * 
 * @author David J. Barnes and Michael Kölling
 * @modified by Taherah Choudhury and Arham Azhary
 * @version 24/02/2021
 */
public class Zebra extends Prey
{
    // Characteristics shared by all zebras (class variables).

    // The age at which a zebra can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a zebra can live.
    private static final int MAX_AGE = 250;
    // The likelihood of a zebra breeding.
    private static final double BREEDING_PROBABILITY = 0.20;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single plant. In effect, this is the
    // number of steps a zebra can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 14;

    /**
     * Create a new zebra. A zebra may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra(boolean randomAge, Weather weather, Field field, Location location)
    {
        super(randomAge, weather, field, location);
    }

    /**
     * This is what the zebra does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newZebras A list to return newly born zebras.
     */
    public void act(List<Organism> newZebras)
    {
        super.act(newZebras);
    }

    /**
     * Return true is given object is an instance of zebra.
     */
    public boolean isInstanceOf(Object object)
    {
        if (object instanceof Zebra){
            return true;
        }
        return false;
    }

    /**
     * Returns Zebras maximum age
     */
    @Override
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Returns the plant food value.
     */
    @Override
    public int getFoodValue()
    {
        return PLANT_FOOD_VALUE;
    }

    /**
     * Returns the max litter size.
     */
    @Override
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Returns the zebras breading age.
     */
    @Override
    public int getBreadingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Returns the zebras breading probability.
     */
    @Override
    public double getBreadingProb()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Adds newly born zebras to the field at a free location
     */
    public void addNewAnimals(Field field, List<Location> free, Weather weather, List<Organism> newZebras)
    {
        Location loc = free.remove(0);
        Zebra young = new Zebra(false, weather, field, loc);
        newZebras.add(young);
    }
}    

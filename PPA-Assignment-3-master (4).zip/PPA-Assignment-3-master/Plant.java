import java.util.List;

/**
 * Class Plant - plants are scattered randomly in the field.
 * Main food source for all the prey in the habitat.
 * Grows at a given rate and does not move.
 * 
 * @author Taherah Choudhury and Arham Azhary
 * @version 26/02/2021
 */
public class Plant extends Organism
{
    private static final int GROWTH_RATE = 2;
    private static final int MAX_AGE = 100;

    private int age;
    
    /**
     * Constructor for objects of class Plant
     */
    public Plant(Field field, Weather weather, Location location)
    {
        super(field, weather, location);
        age = 5;
    }
    
    @Override
    public void act(List<Organism> newOrganisms)
    {
        incrementAge();
        if(isAlive() && getWeather().isRaining()) {
            incrementAge();
        }
    }
    
    /**
     * Age of this plant is increased by the growth rate.
     */
    public void incrementAge()
    {
        age += GROWTH_RATE;
        if(age > MAX_AGE) {
            age = 0; // Plant grows again
        }
    }
}


/**
 * Abstract class Prey - Sub class of Animal
 *
 * @author Taherah Choudhury and Arham Azhary
 * @version 24/02/2021 (1)
 */
public abstract class Prey extends Animal
{
    
    /**
     * Create a new Prey at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(boolean randomAge, Weather weather, Field field, Location location)
    {
        super(randomAge, weather, field, location);
    }
    
    /**
     * Returns true if object is the preys food source (plant)
     */
    @Override
    public boolean isFood(Object object)
    {
        if(object instanceof Plant){
            return true;
        }
        return false;
    }
}

/**
 * Enumeration class Gender
 *
 * @author Taherah Choudhury and Arham Azhary
 * @version 01/03/2021
 */
public enum Gender
{
    MALE, FEMALE;
}

import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a Hyena.
 * Hyena age, move, eat warthogs, and die.
 * 
 * @author David J. Barnes and Michael Kölling
 * @modified by Taherah Choudhury and Arham Azhary
 * @version 24/02/2021 (3) 
 */
public class Hyena extends Predator
{
    // Characteristics shared by all hyenas (class variables).

    // The age at which a hyena can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a hyena can live.
    private static final int MAX_AGE = 250;
    // The likelihood of a hyena breeding.
    private static final double BREEDING_PROBABILITY = 0.05;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single warthog. In effect, this is the
    // number of steps a hyena can go before it has to eat again.
    private static final int WARTHOG_FOOD_VALUE = 13;

    /**
     * Create a hyena. A hyena can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the hyena will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hyena(boolean randomAge, Weather weather, Field field, Location location)
    {
        super(randomAge, weather, field, location);
    }

    /**
     * This is what the hyena does most of the time: it hunts for
     * warthogs. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newHyenas A list to return newly born hyenas.
     */
    public void act(List<Organism> newHyenas)
    {
        super.act(newHyenas);
    }

    /**
     * Return true is given object is an instance of hyena.
     */
    public boolean isInstanceOf(Object object)
    {
        if (object instanceof Hyena){
            return true;
        }
        return false;
    }

    /**
     * Returns Hyena maximum age.
     */
    @Override
    public int getMaxAge() 
    {
        return MAX_AGE; 
    }

    /**
     * Returns the zebras (lions prey) food value.
     */
    @Override
    public int getFoodValue()
    {
        return WARTHOG_FOOD_VALUE;
    }

    /**
     * Returns the max litter size.
     */
    @Override
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Returns the lions breading age.
     */
    @Override
    public int getBreadingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Returns the lions breading probability.
     */
    @Override
    public double getBreadingProb()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Returns true if object is Hyenas prey (warthog)
     */
    @Override
    public boolean isFood(Object object)
    {
        if(object instanceof Warthog){
            return true;
        }
        return false;
    }

    /**
     * Adds newly born hyenas to the field at a free location
     */
    public void addNewAnimals(Field field, List<Location> free, Weather weather, List<Organism> newHyenas)
    {
        Location loc = free.remove(0);
        Hyena young = new Hyena(false, weather, field, loc);
        newHyenas.add(young);
    }
}

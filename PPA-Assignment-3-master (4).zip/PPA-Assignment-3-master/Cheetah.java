import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a Cheetah.
 * Cheetah age, move, eat zebras, and die.
 * 
 * @author David J. Barnes and Michael Kölling
 * @modified by Taherah Choudhury and Arham Azhary
 * @version 24/02/2021 (3) 
 */
public class Cheetah extends Predator
{
    // Characteristics shared by all Cheetahs (class variables).

    // The age at which a Cheetah can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a Cheetah can live.
    private static final int MAX_AGE = 300;
    // The likelihood of a Cheetah breeding.
    private static final double BREEDING_PROBABILITY = 0.08;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single zebra. In effect, this is the
    // number of steps a Cheetah can go before it has to eat again.
    private static final int ZEBRA_FOOD_VALUE = 12;

    /**
     * Create a Cheetah. A Cheetah can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Cheetah will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cheetah(boolean randomAge, Weather weather, Field field, Location location)
    {
        super(randomAge, weather, field, location);
    }

    /**
     * This is what the Cheetah does most of the time: it hunts for
     * zebras. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newCheetahs A list to return newly born cheetahs.
     */
    public void act(List<Organism> newCheetahs)
    {
        super.act(newCheetahs);
    }

    /**
     * Return true is given object is an instance of cheetah.
     */
    public boolean isInstanceOf(Object object)
    {
        if (object instanceof Cheetah){
            return true;
        }
        return false;
    }

    /**
     * Returns Cheetah maximum age.
     */
    @Override
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Returns the zebras (cheetahs prey) food value.
     */
    @Override
    public int getFoodValue()
    {
        return ZEBRA_FOOD_VALUE;
    }

    /**
     * Returns the max litter size.
     */
    @Override
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Returns the cheetahs breading age.
     */
    @Override
    public int getBreadingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Returns the cheetahs breading probability.
     */
    @Override
    public double getBreadingProb()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Returns true if object is Cheetahs prey (zebra)
     */
    @Override
    public boolean isFood(Object object)
    {
        if(object instanceof Zebra){
            return true;
        }
        return false;
    }

    /**
     * Adds newly born cheetahs to the field at a free location
     */
    public void addNewAnimals(Field field, List<Location> free, Weather weather, List<Organism> newCheetahs)
    {
        Location loc = free.remove(0);
        Cheetah young = new Cheetah(false, weather, field, loc);
        newCheetahs.add(young);
    }
}

import java.util.List;

/**
 * A simple model of a warthog.
 * Warthogs age, move, breed, and die.
 * 
 * @author David J. Barnes and Michael Kölling
 * @modified by Taherah Choudhury and Arham Azhary
 * @version 24/02/2021 (3) 
 */
public class Warthog extends Prey
{
    // Characteristics shared by all warthogs (class variables).

    // The age at which a warthog can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a warthog can live.
    private static final int MAX_AGE = 250;
    // The likelihood of a warthog breeding.
    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single plant. In effect, this is the
    // number of steps a warthog can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 14;

    /**
     * Create a new warthog. A Warthog may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the rabbit will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Warthog(boolean randomAge, Weather weather, Field field, Location location)
    {
        super(randomAge, weather, field, location);
    }

    /**
     * This is what the warthog does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newWarthogs A list to return newly born warhogs.
     */
    public void act(List<Organism> newWarthogs)
    {
        super.act(newWarthogs);
    }

    /**
     * Return true is given object is an instance of cheetah.
     */
    public boolean isInstanceOf(Object object)
    {
        if (object instanceof Zebra){
            return true; 
        }
        return false;
    }

    /**
     * Returns warthog maximum age
     */
    @Override
    public int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Returns the plant food value.
     */
    @Override
    public int getFoodValue()
    {
        return PLANT_FOOD_VALUE;
    }

    /**
     * Returns the max litter size.
     */
    @Override
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Returns the warthog breading age.
     */
    @Override
    public int getBreadingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Returns the warthogs breading probability.
     */
    @Override
    public double getBreadingProb()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Adds newly born warthogs to the field at a free location
     */
    public void addNewAnimals(Field field, List<Location> free, Weather weather, List<Organism> newWarthogs)
    {
        Location loc = free.remove(0);
        Warthog young = new Warthog(false, weather, field, loc);
        newWarthogs.add(young);
    }
}


/**
 * The ClockDisplay class internally implements a digital clock display for a
 * European-style 24 hour clock. The clock shows hours and minutes. The 
 * range of the clock is 00:00 (midnight) to 23:59 (one minute before 
 * midnight).
 * 
 * The clock display receives "ticks" (via the timeTick method) every minute
 * and reacts by incrementing the display. This is done in the usual clock
 * fashion: the hour increments when the minutes roll over to zero.
 * 
 * The clock display actually displays a 12-hour clock
 *
 * @author Michael Kölling and David J. Barnes 
 * @modified by Taherah Choudhury and Arham Azhary
 * @version 27/02/2021 (2)
 */
public class ClockDisplay
{
    private NumberDisplay hours;
    private NumberDisplay minutes;
    private String displayString;    // simulates the actual display
    private String clockPeriod = "PM";

    /**
     * Constructor for ClockDisplay objects. This constructor 
     * creates a new clock set at 12:00.
     */
    public ClockDisplay()
    {
        hours = new NumberDisplay(13);
        minutes = new NumberDisplay(60);
        setTime(12, 0);
    }

    /**
     * This method should get called once every minute - it makes
     * the clock display go one minute forward. 
     */
    public void timeTick()
    {
        minutes.increment();
        if(minutes.getValue() == 0) {  // it just rolled over
            hours.increment();
            if(hours.getValue() == 0 && clockPeriod == "AM"){ //it's now past midnight
                hours.setValue(1);
                clockPeriod = "PM";
            }
            else if (hours.getValue() == 0 && clockPeriod == "PM"){ //it's now after midnight
                hours.setValue(1);
                clockPeriod = "AM"; 
            }
        }
        updateDisplay();
    }

    /**
     * Set the time of the display to the specified hour and
     * minute.
     */
    public void setTime(int hour, int minute)
    {
        minutes.setValue(minute);
        if (hour > 12)
        {
            hours.setValue(hour - 12);
            clockPeriod = "PM"; 
        }
        else
        {
            hours.setValue(hour);
            clockPeriod = "AM";
        }
        updateDisplay();
    }

    /**
     * Return the current time of this display in the format HH:MM.
     */
    public String getTime()
    {
        return displayString;
    }

    /**
     * Update the internal string that represents the display.
     */
    private void updateDisplay()
    {
        displayString = hours.getDisplayValue() + ":" + 
        minutes.getDisplayValue() + clockPeriod;
    }
    
    /**
     * Returns the current hour of this clock display
     */
    public int getHour()
    {
        return hours.getValue();
    }
    
    /**
     * Returns the clock Period (AM or PM)
     */
    public String getPeriod()
    {
        return clockPeriod;
    }
    
    /**
     * Reset the internal string that represents the display.
     */
    public void reset()
    {
        hours.setValue(13);
        minutes.setValue(0);
        clockPeriod = "AM";
        displayString = hours.getDisplayValue() + ":" + 
        minutes.getDisplayValue() + clockPeriod;
    }
}
